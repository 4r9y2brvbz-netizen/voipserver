# Security notes

- The launcher passes the selected key path directly to OpenSSH. It never reads,
  copies or serializes the key. OpenSSH host-key trust is recorded normally.
- The application bundle excludes keys, database files and environment secrets.
- Admin passwords use `scrypt`; CDR ingestion uses a random server-local bearer
  token. Originators are IP-authenticated. Terminators may use IP authentication
  or outbound SIP registration.
- A registering SIP trunk requires FreeSWITCH to recover its provider password,
  so that password is stored locally rather than hashed. It is excluded from API
  list responses and redacted in previews. The state directory and generated XML
  are protected by server-local ownership and modes; protect root/panel access
  and backups accordingly. Never commit provider credentials to GitHub.
- Restrict HTTP/HTTPS, SSH and SIP firewall rules to known CIDRs before production.
  The supplied firewall is a connectivity-safe baseline, not a carrier ACL.
- Add TLS at nginx before exposing the panel. Plain HTTP is suitable only through
  a private network or SSH tunnel.
- Protect database backups: balances, numbers and CDR are sensitive. Use encrypted
  off-server backup storage and document retention/deletion policy.
- Run the panel as `voipapp`; FreeSWITCH remains a separate service identity.
- Review local law, emergency calling, lawful intercept and privacy requirements.

