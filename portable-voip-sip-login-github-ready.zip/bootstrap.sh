#!/bin/sh
# First-boot bootstrap for a new DigitalOcean Ubuntu 24.04 LTS Droplet.
set -eu

LOG=/var/log/portable-voip-install.log
STATUS=/var/lib/portable-voip-install.status
exec >>"$LOG" 2>&1

fail() {
  code=$?
  printf 'FAILED exit=%s time=%s\n' "$code" "$(date -u +%FT%TZ)" > "$STATUS"
  exit "$code"
}
trap fail HUP INT TERM EXIT

: "${REPO_URL:?Set REPO_URL to the public GitHub repository URL}"
case "$REPO_URL" in
  https://github.com/*/*|https://github.com/*/*.git) ;;
  *) echo "REPO_URL must be an https://github.com/OWNER/REPOSITORY URL"; exit 20 ;;
esac

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends ca-certificates curl git

install -d -m 0750 /opt/portable-voip-source
if [ -d /opt/portable-voip-source/.git ]; then
  git -C /opt/portable-voip-source fetch --depth 1 origin "${REPO_REF:-main}"
  git -C /opt/portable-voip-source reset --hard FETCH_HEAD
else
  git clone --depth 1 --branch "${REPO_REF:-main}" "$REPO_URL" /opt/portable-voip-source
fi

cd /opt/portable-voip-source
test -f deploy/install.sh
install -d -m 0750 /opt/portable-voip/releases
if [ -d /opt/portable-voip/releases/incoming ]; then
  mv /opt/portable-voip/releases/incoming "/opt/portable-voip/releases/failed-$(date -u +%Y%m%dT%H%M%SZ)"
fi
install -d -m 0750 /opt/portable-voip/releases/incoming
tar -cf - --exclude=.git . | tar -xf - -C /opt/portable-voip/releases/incoming
sh deploy/install.sh
printf 'READY time=%s panel=http://%s/\n' "$(date -u +%FT%TZ)" "$(curl -4fsS https://api.ipify.org || hostname -I | awk '{print $1}')" > "$STATUS"
trap - HUP INT TERM EXIT
echo "Portable VoIP installation complete"

