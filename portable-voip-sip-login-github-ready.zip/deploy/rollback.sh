#!/bin/sh
set -eu
BACKUPS=/var/backups/portable-voip
ROOT=/opt/portable-voip
STATE=/var/lib/portable-voip
marker=$(ls -1t "$BACKUPS"/*.previous-release 2>/dev/null | head -1)
test -n "$marker"
previous=$(cat "$marker")
test -d "$previous"
systemctl stop portable-voip
db=$(ls -1t "$BACKUPS"/*.db 2>/dev/null | head -1 || true)
if [ -n "$db" ]; then cp -a "$db" "$STATE/voip.db"; chown voipapp:voipapp "$STATE/voip.db"; fi
ln -sfn "$previous" "$ROOT/current.new" && mv -Tf "$ROOT/current.new" "$ROOT/current"
systemctl start portable-voip
port=8088
systemctl cat portable-voip 2>/dev/null | grep -q -- '--port 18088' && port=18088
curl -fsS "http://127.0.0.1:$port/api/health"

