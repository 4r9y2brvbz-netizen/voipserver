#!/bin/sh
# Install Portable VoIP without changing an existing web/mail/DNS stack.
set -eu
export PORTABLE_VOIP_COEXIST=1
exec sh "$(dirname "$0")/install.sh"
