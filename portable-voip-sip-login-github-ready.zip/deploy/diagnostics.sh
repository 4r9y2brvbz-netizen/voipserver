#!/bin/sh
set -u
echo "== Portable VoIP diagnostics $(date -u +%FT%TZ) =="
systemctl --no-pager --full status portable-voip freeswitch 2>&1
port=8088
systemctl cat portable-voip 2>/dev/null | grep -q -- '--port 18088' && port=18088
echo "== health =="; curl -fsS "http://127.0.0.1:$port/api/health" 2>&1
echo "== sockets =="; ss -lntup 2>&1
echo "== disk =="; df -h / /var/lib/portable-voip 2>&1
echo "== database =="; sqlite3 /var/lib/portable-voip/voip.db 'pragma integrity_check;' 2>&1
echo "== recent service logs =="; journalctl -u portable-voip -u freeswitch -n 100 --no-pager 2>&1

