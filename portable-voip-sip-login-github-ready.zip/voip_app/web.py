from __future__ import annotations

import json
import mimetypes
import secrets
import sqlite3
import subprocess
import re
from contextlib import contextmanager
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .db import add_ledger, connect, rate_cdr, verify_password
from .freeswitch import generate, reload_configuration, write_atomic


ASSETS = Path(__file__).with_name("static")
SESSIONS: dict[str, str] = {}


class App(ThreadingHTTPServer):
    def __init__(self, address: tuple[str, int], db_path: Path, config_dir: Path):
        super().__init__(address, Handler)
        self.db_path, self.config_dir = db_path, config_dir


class Handler(BaseHTTPRequestHandler):
    server: App

    @contextmanager
    def db(self):
        connection = connect(self.server.db_path)
        try:
            yield connection
        finally:
            connection.close()

    def send_json(self, value: object, status: int = 200, headers: dict[str, str] | None = None) -> None:
        body = json.dumps(value, separators=(",", ":"), default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        for key, val in (headers or {}).items():
            self.send_header(key, val)
        self.end_headers(); self.wfile.write(body)

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length > 1_000_000:
            raise ValueError("request too large")
        return json.loads(self.rfile.read(length) or b"{}")

    def session(self) -> str | None:
        jar = cookies.SimpleCookie(self.headers.get("Cookie"))
        token = jar.get("session")
        return SESSIONS.get(token.value) if token else None

    def authorized(self) -> bool:
        if self.path == "/api/login" or self.path == "/api/cdr-ingest":
            return True
        return self.session() is not None

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/health":
            return self.send_json({"status": "ok", "database": self.server.db_path.exists()})
        if parsed.path.startswith("/api/") and not self.authorized():
            return self.send_json({"error": "authentication required"}, 401)
        if parsed.path == "/api/summary": return self.summary()
        if parsed.path == "/api/originators": return self.originators()
        if parsed.path == "/api/terminators": return self.terminators()
        if parsed.path == "/api/destinations": return self.destinations()
        if parsed.path == "/api/routes": return self.routes()
        if parsed.path == "/api/caller-id-pools": return self.caller_id_pools()
        if parsed.path == "/api/accounts": return self.accounts()
        if parsed.path == "/api/cdr": return self.cdr(parsed.query)
        if parsed.path == "/api/active-calls": return self.active_calls()
        if parsed.path == "/api/config-preview":
            with self.db() as db: return self.send_json(generate(db, redact_secrets=True))
        return self.static(parsed.path)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            data = self.read_json()
            if path == "/api/login": return self.login(data)
            if path == "/api/cdr-ingest": return self.ingest(data)
            if not self.authorized(): return self.send_json({"error": "authentication required"}, 401)
            if path == "/api/originators": return self.create_originator(data)
            if path == "/api/terminators": return self.create_terminator(data)
            if path == "/api/destinations": return self.create_destination(data)
            if path == "/api/routes": return self.create_route(data)
            if path == "/api/caller-id-pools": return self.create_caller_id_pool(data)
            if path == "/api/rates": return self.create_rate(data)
            if path == "/api/ledger": return self.ledger(data)
            if path == "/api/config-activate": return self.activate()
            self.send_json({"error": "not found"}, 404)
        except (ValueError, KeyError, RuntimeError, sqlite3.IntegrityError) as exc:
            self.send_json({"error": str(exc)}, 400)

    def login(self, data: dict) -> None:
        with self.db() as db:
            user = db.execute("SELECT value FROM settings WHERE key='admin_user'").fetchone()
            pw = db.execute("SELECT value FROM settings WHERE key='admin_password_hash'").fetchone()
        if not user or not pw or data.get("username") != user["value"] or not verify_password(str(data.get("password", "")), pw["value"]):
            return self.send_json({"error": "invalid credentials"}, 401)
        token = secrets.token_urlsafe(32); SESSIONS[token] = user["value"]
        self.send_json({"ok": True}, headers={"Set-Cookie": f"session={token}; HttpOnly; SameSite=Strict; Path=/"})

    def summary(self) -> None:
        with self.db() as db:
            counts = {name: db.execute(f"SELECT count(*) n FROM {name}").fetchone()["n"] for name in ("originators", "terminators", "routes", "cdr")}
            balance = db.execute("SELECT party_type,sum(balance_micros) total FROM accounts GROUP BY party_type").fetchall()
            recent = [dict(r) for r in db.execute("SELECT uuid,called,bill_seconds,hangup_cause,started_at FROM cdr ORDER BY started_at DESC LIMIT 6")]
        self.send_json({"counts": counts, "balances": {r["party_type"]: r["total"] for r in balance}, "recent": recent})

    def table(self, name: str) -> None:
        with self.db() as db: rows = [dict(r) for r in db.execute(f"SELECT * FROM {name} ORDER BY id DESC")]
        self.send_json(rows)

    def originators(self) -> None:
        with self.db() as db:
            rows = [dict(r) for r in db.execute("""SELECT o.*,group_concat(oi.cidr,' ') ips,coalesce(a.balance_micros,0) balance_micros,a.currency
              FROM originators o LEFT JOIN originator_ips oi ON oi.originator_id=o.id
              LEFT JOIN accounts a ON a.party_type='originator' AND a.party_id=o.id
              GROUP BY o.id ORDER BY o.name""")]
        self.send_json(rows)

    def terminators(self) -> None:
        with self.db() as db:
            rows = [dict(r) for r in db.execute("""SELECT t.id,t.name,t.host,t.tech_prefix,t.connection_type,t.sip_username,t.sip_realm,t.sip_transport,t.enabled,t.created_at,
              coalesce(a.balance_micros,0) balance_micros,a.currency,
              (SELECT count(*) FROM routes r WHERE r.terminator_id=t.id AND r.enabled=1) route_count
              FROM terminators t LEFT JOIN accounts a ON a.party_type='terminator' AND a.party_id=t.id ORDER BY t.name""")]
        self.send_json(rows)

    def destinations(self) -> None:
        with self.db() as db:
            rows = [dict(r) for r in db.execute("SELECT d.*,group_concat(p.prefix,', ') prefixes FROM destinations d LEFT JOIN prefixes p ON p.destination_id=d.id GROUP BY d.id ORDER BY d.name")]
        self.send_json(rows)

    def routes(self) -> None:
        with self.db() as db:
            rows = [dict(r) for r in db.execute("""SELECT r.*,o.name originator,d.name destination,t.name terminator,t.host terminator_ip,t.tech_prefix,
              group_concat(DISTINCT p.prefix) prefixes,cip.name caller_id_pool,
              (SELECT count(*) FROM caller_id_numbers cin WHERE cin.pool_id=r.caller_id_pool_id) caller_id_count,
              (SELECT price_micros FROM rates x WHERE x.party_type='originator' AND x.party_id=r.originator_id AND x.destination_id=r.destination_id ORDER BY effective_at DESC LIMIT 1) sell_micros,
              (SELECT cycle FROM rates x WHERE x.party_type='originator' AND x.party_id=r.originator_id AND x.destination_id=r.destination_id ORDER BY effective_at DESC LIMIT 1) sell_cycle,
              (SELECT price_micros FROM rates x WHERE x.party_type='terminator' AND x.party_id=r.terminator_id AND x.destination_id=r.destination_id ORDER BY effective_at DESC LIMIT 1) buy_micros,
              (SELECT cycle FROM rates x WHERE x.party_type='terminator' AND x.party_id=r.terminator_id AND x.destination_id=r.destination_id ORDER BY effective_at DESC LIMIT 1) buy_cycle
              FROM routes r JOIN originators o ON o.id=r.originator_id JOIN destinations d ON d.id=r.destination_id
              JOIN terminators t ON t.id=r.terminator_id LEFT JOIN prefixes p ON p.destination_id=d.id
              LEFT JOIN caller_id_pools cip ON cip.id=r.caller_id_pool_id
              GROUP BY r.id ORDER BY o.name,d.name,r.priority""")]
        self.send_json(rows)

    def caller_id_pools(self) -> None:
        with self.db() as db:
            rows = [dict(r) for r in db.execute("""SELECT p.*,group_concat(n.number,char(10)) numbers,count(n.id) number_count
              FROM caller_id_pools p LEFT JOIN caller_id_numbers n ON n.pool_id=p.id
              GROUP BY p.id ORDER BY p.name""")]
        self.send_json(rows)

    def accounts(self) -> None:
        with self.db() as db: rows = [dict(r) for r in db.execute("SELECT * FROM accounts ORDER BY party_type,party_id")]
        self.send_json(rows)

    def cdr(self, query: str) -> None:
        q = parse_qs(query).get("number", [""])[0]
        with self.db() as db:
            rows = [dict(r) for r in db.execute("SELECT * FROM cdr WHERE caller LIKE ? OR called LIKE ? ORDER BY started_at DESC LIMIT 200", (f"%{q}%", f"%{q}%"))]
        self.send_json(rows)

    def active_calls(self) -> None:
        try:
            result = subprocess.run(["fs_cli", "-x", "show channels as json"], capture_output=True, text=True, timeout=3, check=False)
            if result.returncode:
                return self.send_json({"available": False, "calls": [], "detail": result.stderr.strip()})
            payload = json.loads(result.stdout or "{}")
            rows = payload.get("rows", payload.get("channels", []))
            self.send_json({"available": True, "calls": rows if isinstance(rows, list) else []})
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as exc:
            self.send_json({"available": False, "calls": [], "detail": str(exc)})

    def create_originator(self, d: dict) -> None:
        from .db import validate_cidr
        with self.db() as db:
            cur = db.execute("INSERT INTO originators(name) VALUES(?)", (str(d["name"]).strip(),))
            oid = cur.lastrowid
            for cidr in d.get("cidrs", []): db.execute("INSERT INTO originator_ips(originator_id,cidr) VALUES(?,?)", (oid, validate_cidr(cidr)))
        self.send_json({"id": oid}, 201)

    def create_terminator(self, d: dict) -> None:
        name = str(d["name"]).strip()
        host = str(d["host"]).strip()
        connection_type = str(d.get("connection_type", "direct")).strip().lower()
        username = str(d.get("sip_username", "")).strip()
        password = str(d.get("sip_password", ""))
        realm = str(d.get("sip_realm", "")).strip()
        transport = str(d.get("sip_transport", "udp")).strip().lower()
        tech_prefix = str(d.get("tech_prefix", "")).strip()
        if not name:
            raise ValueError("account name is required")
        if not re.fullmatch(r"(?:sip:)?(?:\[[0-9A-Fa-f:]+\]|[A-Za-z0-9.-]+)(?::[0-9]{1,5})?", host):
            raise ValueError("SIP server must be a hostname or IP, optionally with a port")
        if connection_type not in {"direct", "registration"}:
            raise ValueError("connection type must be direct or registration")
        if transport not in {"udp", "tcp"}:
            raise ValueError("SIP transport must be udp or tcp")
        if tech_prefix and not tech_prefix.isdigit():
            raise ValueError("tech prefix must contain digits only")
        if connection_type == "registration" and (not username or not password):
            raise ValueError("SIP username and password are required for registration")
        if realm and not re.fullmatch(r"(?:\[[0-9A-Fa-f:]+\]|[A-Za-z0-9.-]+)(?::[0-9]{1,5})?", realm):
            raise ValueError("SIP realm must be a hostname or IP")
        with self.db() as db:
            cur = db.execute("""INSERT INTO terminators
              (name,host,tech_prefix,connection_type,sip_username,sip_password,sip_realm,sip_transport)
              VALUES(?,?,?,?,?,?,?,?)""", (name, host, tech_prefix, connection_type, username, password, realm, transport))
        self.send_json({"id": cur.lastrowid}, 201)

    def create_destination(self, d: dict) -> None:
        with self.db() as db:
            cur = db.execute("INSERT INTO destinations(name) VALUES(?)", (d["name"],)); did = cur.lastrowid
            for prefix in d.get("prefixes", []): db.execute("INSERT INTO prefixes(destination_id,prefix) VALUES(?,?)", (did, str(prefix)))
        self.send_json({"id": did}, 201)

    def create_route(self, d: dict) -> None:
        pool_id = d.get("caller_id_pool_id") or None
        with self.db() as db: cur = db.execute("INSERT INTO routes(originator_id,destination_id,terminator_id,caller_id_pool_id,client_tech_prefix,priority) VALUES(?,?,?,?,?,?)", (d["originator_id"], d["destination_id"], d["terminator_id"], pool_id, d.get("client_tech_prefix", ""), d.get("priority", 100)))
        self.send_json({"id": cur.lastrowid}, 201)

    def create_caller_id_pool(self, d: dict) -> None:
        from .db import normalize_caller_ids
        numbers = normalize_caller_ids(d.get("numbers", []))
        with self.db() as db:
            cur = db.execute("INSERT INTO caller_id_pools(name) VALUES(?)", (str(d["name"]).strip(),))
            pool_id = int(cur.lastrowid)
            db.executemany("INSERT INTO caller_id_numbers(pool_id,number) VALUES(?,?)", ((pool_id, number) for number in numbers))
        self.send_json({"id": pool_id, "number_count": len(numbers)}, 201)

    def create_rate(self, d: dict) -> None:
        with self.db() as db: cur = db.execute("INSERT INTO rates(party_type,party_id,destination_id,price_micros,cycle,effective_at) VALUES(?,?,?,?,?,coalesce(?,CURRENT_TIMESTAMP))", (d["party_type"], d["party_id"], d["destination_id"], d["price_micros"], d["cycle"], d.get("effective_at")))
        self.send_json({"id": cur.lastrowid}, 201)

    def ledger(self, d: dict) -> None:
        with self.db() as db:
            add_ledger(db, d["party_type"], int(d["party_id"]), int(d["amount_micros"]), d.get("kind", "adjustment"), d.get("reference", secrets.token_hex(8)), d.get("note", ""))
        self.send_json({"ok": True}, 201)

    def ingest(self, d: dict) -> None:
        expected = ""
        with self.db() as db:
            row = db.execute("SELECT value FROM settings WHERE key='cdr_token'").fetchone(); expected = row["value"] if row else ""
            if not expected or not secrets.compare_digest(self.headers.get("Authorization", ""), f"Bearer {expected}"):
                return self.send_json({"error": "unauthorized"}, 401)
            cid = rate_cdr(db, d)
        self.send_json({"id": cid}, 201)

    def activate(self) -> None:
        with self.db() as db: files = generate(db)
        write_atomic(files, self.server.config_dir)
        reload_result = reload_configuration(self.server.config_dir)
        self.send_json({"ok": True, "files": sorted(files), **reload_result})

    def static(self, path: str) -> None:
        name = "index.html" if path in {"", "/"} else path.lstrip("/")
        file = (ASSETS / name).resolve()
        if ASSETS.resolve() not in file.parents or not file.is_file():
            return self.send_json({"error": "not found"}, 404)
        body = file.read_bytes(); self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(file.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"{self.address_string()} {fmt % args}")

