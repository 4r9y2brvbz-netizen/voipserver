from __future__ import annotations

import html
import ipaddress
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
import sqlite3


def x(value: object) -> str:
    return html.escape(str(value), quote=True)


def generate(db: sqlite3.Connection, *, redact_secrets: bool = False) -> dict[str, str]:
    acls = db.execute("""SELECT o.id,o.name,oi.cidr FROM originators o JOIN originator_ips oi ON oi.originator_id=o.id WHERE o.enabled=1 ORDER BY o.id,oi.cidr""").fetchall()
    terminators = db.execute("SELECT * FROM terminators WHERE enabled=1 ORDER BY id").fetchall()
    routes = db.execute("""SELECT r.*,p.prefix,t.host,t.tech_prefix FROM routes r JOIN prefixes p ON p.destination_id=r.destination_id JOIN terminators t ON t.id=r.terminator_id WHERE r.enabled=1 AND t.enabled=1 ORDER BY length(p.prefix) DESC,r.priority""").fetchall()
    caller_ids = db.execute("""SELECT p.id pool_id,n.number,n.weight FROM caller_id_pools p
      JOIN caller_id_numbers n ON n.pool_id=p.id WHERE p.enabled=1 ORDER BY p.id,n.id""").fetchall()
    grouped: dict[int, list[sqlite3.Row]] = {}
    for row in acls:
        grouped.setdefault(int(row["id"]), []).append(row)
    acl_lists = []
    for originator_id, rows in grouped.items():
        nodes = "\n".join(f'      <node type="allow" cidr="{x(row["cidr"])}"/>' for row in rows)
        acl_lists.append(f'    <list name="portable-originator-{originator_id}" default="deny">\n{nodes}\n    </list>')
    acl_xml = f'''<configuration name="acl.conf" description="portable-voip generated ACL">
  <network-lists>\n{chr(10).join(acl_lists)}\n  </network-lists>
</configuration>'''
    gateway_blocks = []
    for row in terminators:
        params = [f'    <param name="proxy" value="{x(row["host"])}"/>']
        if row["connection_type"] == "registration":
            realm = row["sip_realm"] or row["host"]
            password = "********" if redact_secrets else row["sip_password"]
            params.extend([
                f'    <param name="username" value="{x(row["sip_username"])}"/>',
                f'    <param name="password" value="{x(password)}"/>',
                f'    <param name="realm" value="{x(realm)}"/>',
                f'    <param name="from-user" value="{x(row["sip_username"])}"/>',
                f'    <param name="from-domain" value="{x(realm)}"/>',
                '    <param name="register" value="true"/>',
                f'    <param name="register-transport" value="{x(row["sip_transport"])}"/>',
                '    <param name="expire-seconds" value="3600"/>',
                '    <param name="retry-seconds" value="30"/>',
                f'    <param name="extension" value="{x(row["sip_username"])}"/>',
                '    <param name="context" value="public"/>',
                '    <param name="ping" value="30"/>',
            ])
        else:
            params.extend([
                '    <param name="register" value="false"/>',
                '    <param name="context" value="public"/>',
            ])
        gateway_blocks.append(f'  <gateway name="term_{row["id"]}">\n' + "\n".join(params) + "\n  </gateway>")
    gateways = "\n".join(gateway_blocks)
    gateway_xml = f'<include>\n{gateways}\n</include>'
    caller_groups: dict[int, list[sqlite3.Row]] = {}
    for row in caller_ids:
        caller_groups.setdefault(int(row["pool_id"]), []).append(row)
    distributor_lists = []
    for pool_id, rows in caller_groups.items():
        nodes = "\n".join(f'      <node name="{x(row["number"])}" weight="{int(row["weight"])}"/>' for row in rows)
        distributor_lists.append(f'    <list name="portable-caller-{pool_id}">\n{nodes}\n    </list>')
    distributor_xml = f'''<configuration name="distributor.conf" description="portable-voip A-number pools">
  <lists>\n{chr(10).join(distributor_lists)}\n  </lists>
</configuration>'''
    extensions = []
    for row in routes:
        prefix = x(row["prefix"])
        dial = x(row["tech_prefix"])
        caller_actions = ""
        if row["caller_id_pool_id"] and int(row["caller_id_pool_id"]) in caller_groups:
            pool_id = int(row["caller_id_pool_id"])
            caller_actions = f'''        <action application="distributor" data="portable-caller-{pool_id}"/>
        <action application="set" data="origination_caller_id_number=${{DISTRIBUTOR}}"/>
        <action application="set" data="origination_caller_id_name=${{DISTRIBUTOR}}"/>
        <action application="set" data="portable_original_caller_id=${{caller_id_number}}"/>\n'''
        extensions.append(f'''  <extension name="route_{row['id']}">
    <condition field="destination_number" expression="^{prefix}(\\d*)$">
      <condition field="${{acl(${{network_addr}} portable-originator-{row['originator_id']})}}" expression="^true$">
        <action application="set" data="portable_originator_id={row['originator_id']}"/>
        <action application="set" data="portable_terminator_id={row['terminator_id']}"/>
{caller_actions.rstrip()}
        <action application="bridge" data="sofia/gateway/term_{row['terminator_id']}/{dial}${{destination_number}}"/>
      </condition>
    </condition>
  </extension>''')
    dialplan = '<include>\n<context name="public">\n' + "\n".join(extensions) + '\n</context>\n</include>'
    return {"acl.conf.xml": acl_xml, "gateways.xml": gateway_xml, "dialplan.xml": dialplan, "distributor.conf.xml": distributor_xml}


def write_atomic(files: dict[str, str], target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=target.parent, prefix=".generation-") as tmp:
        stage = Path(tmp)
        for name, content in files.items():
            path = stage / name
            path.write_text(content + "\n")
            os.chmod(path, 0o640)
        old = target.with_name(target.name + ".previous")
        if old.exists():
            for item in old.iterdir():
                item.unlink()
            old.rmdir()
        if target.exists():
            target.rename(old)
        stage.rename(target)
        os.chmod(target, 0o750)


def reload_configuration(target: Path) -> dict[str, object]:
    """Reload generated configuration without restarting FreeSWITCH.

    A development machine may not have fs_cli installed; in that case the
    generated files remain valid and the caller receives an explicit skipped
    result. On a deployed node a failed reload restores the previous generation
    and tries to load it again before reporting the error.
    """
    fs_cli = shutil.which("fs_cli")
    if not fs_cli:
        return {"reloaded": False, "detail": "fs_cli is not installed on this machine"}
    commands = [
        "reloadxml",
        "sofia profile external rescan",
        "distributor_ctl reload",
    ]

    def run(command: str) -> str:
        result = subprocess.run(
            [fs_cli, "-x", command], capture_output=True, text=True,
            timeout=15, check=False,
        )
        output = (result.stdout + "\n" + result.stderr).strip()
        if result.returncode or "-ERR" in output or "[ERR" in output:
            raise RuntimeError(f"FreeSWITCH command failed ({command}): {output or 'no response'}")
        return output

    outputs: list[str] = []
    try:
        for command in commands:
            outputs.append(run(command))
    except (OSError, subprocess.TimeoutExpired, RuntimeError) as exc:
        previous = target.with_name(target.name + ".previous")
        if previous.is_dir():
            failed = target.with_name(target.name + ".failed")
            if failed.exists():
                shutil.rmtree(failed)
            if target.exists():
                target.rename(failed)
            previous.rename(target)
            try:
                run("reloadxml")
                run("sofia profile external rescan")
                run("distributor_ctl reload")
            except (OSError, subprocess.TimeoutExpired, RuntimeError):
                pass
        raise RuntimeError(str(exc)) from exc
    return {"reloaded": True, "detail": outputs}

