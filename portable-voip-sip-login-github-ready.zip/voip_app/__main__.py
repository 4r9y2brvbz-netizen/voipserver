from __future__ import annotations

import argparse
import os
import secrets
from contextlib import closing
from pathlib import Path

from .db import connect, ensure_admin, init_db, seed_demo
from .web import App


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--db", type=Path, default=Path("/var/lib/portable-voip/voip.db"))
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8088)
    p.add_argument("--config-dir", type=Path, default=Path("/var/lib/portable-voip/generated"))
    p.add_argument("--init-demo", action="store_true")
    args = p.parse_args(); args.db.parent.mkdir(parents=True, exist_ok=True)
    password = os.environ.get("PORTABLE_VOIP_ADMIN_PASSWORD", "change-me-now" if args.init_demo else secrets.token_urlsafe(18))
    with closing(connect(args.db)) as db:
        init_db(db); ensure_admin(db, password)
        db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('cdr_token',?)", (secrets.token_urlsafe(32),))
        if args.init_demo: seed_demo(db)
    if not args.init_demo and "PORTABLE_VOIP_ADMIN_PASSWORD" not in os.environ:
        print(f"Generated one-time admin password: {password}")
    server = App((args.host, args.port), args.db, args.config_dir)
    print(f"Portable VoIP panel listening on http://{args.host}:{args.port}")
    server.serve_forever()


if __name__ == "__main__": main()
