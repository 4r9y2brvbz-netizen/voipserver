from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import math
import os
import secrets
import sqlite3
from pathlib import Path
from typing import Any


def connect(path: str | Path) -> sqlite3.Connection:
    db = sqlite3.connect(str(path), timeout=10, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA busy_timeout=10000")
    return db


def init_db(db: sqlite3.Connection) -> None:
    schema = Path(__file__).with_name("schema.sql").read_text()
    db.executescript(schema)
    columns = {row["name"] for row in db.execute("PRAGMA table_info(routes)")}
    if "client_tech_prefix" not in columns:
        db.execute("ALTER TABLE routes ADD COLUMN client_tech_prefix TEXT NOT NULL DEFAULT ''")
    if "caller_id_pool_id" not in columns:
        db.execute("ALTER TABLE routes ADD COLUMN caller_id_pool_id INTEGER REFERENCES caller_id_pools(id) ON DELETE SET NULL")
    terminator_columns = {row["name"] for row in db.execute("PRAGMA table_info(terminators)")}
    terminator_migrations = {
        "connection_type": "TEXT NOT NULL DEFAULT 'direct'",
        "sip_username": "TEXT NOT NULL DEFAULT ''",
        "sip_password": "TEXT NOT NULL DEFAULT ''",
        "sip_realm": "TEXT NOT NULL DEFAULT ''",
        "sip_transport": "TEXT NOT NULL DEFAULT 'udp'",
    }
    for name, definition in terminator_migrations.items():
        if name not in terminator_columns:
            db.execute(f"ALTER TABLE terminators ADD COLUMN {name} {definition}")
    db.execute("INSERT OR IGNORE INTO schema_migrations(version) VALUES (2)")


def normalize_caller_ids(values: list[str] | str) -> list[str]:
    import re
    tokens = re.split(r"[\s,;]+", values if isinstance(values, str) else " ".join(values))
    result = []
    for token in tokens:
        if not token:
            continue
        if not re.fullmatch(r"\+?[1-9][0-9]{6,14}", token):
            raise ValueError("A-number must contain 7-15 digits in international format")
        number = token.lstrip("+")
        if number not in result:
            result.append(number)
    if not result:
        raise ValueError("A-number pool cannot be empty")
    if len(result) > 200:
        raise ValueError("A-number pool is limited to 200 unique numbers")
    return result


def hash_password(password: str, salt: bytes | None = None) -> str:
    if len(password) < 12:
        raise ValueError("password must contain at least 12 characters")
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return f"scrypt${salt.hex()}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    algorithm, salt_hex, digest_hex = encoded.split("$", 2)
    if algorithm != "scrypt":
        return False
    candidate = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=2**14, r=8, p=1)
    return hmac.compare_digest(candidate.hex(), digest_hex)


def ensure_admin(db: sqlite3.Connection, password: str) -> None:
    db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_user','admin')")
    row = db.execute("SELECT value FROM settings WHERE key='admin_password_hash'").fetchone()
    if not row:
        db.execute("INSERT INTO settings(key,value) VALUES('admin_password_hash',?)", (hash_password(password),))


def validate_cidr(value: str) -> str:
    return str(ipaddress.ip_network(value, strict=False))


def billed_seconds(seconds: int, cycle: str) -> int:
    minimum, increment = (int(part) for part in cycle.split("/"))
    if seconds <= 0:
        return 0
    return max(minimum, math.ceil(seconds / increment) * increment)


def charge_micros(seconds: int, price_per_minute_micros: int, cycle: str) -> int:
    return math.ceil(billed_seconds(seconds, cycle) * price_per_minute_micros / 60)


def add_ledger(db: sqlite3.Connection, party_type: str, party_id: int, amount: int, kind: str, reference: str, note: str = "") -> None:
    if party_type not in {"originator", "terminator"}:
        raise ValueError("unknown party type")
    with db:
        db.execute("INSERT OR IGNORE INTO accounts(party_type,party_id) VALUES(?,?)", (party_type, party_id))
        account = db.execute("SELECT id FROM accounts WHERE party_type=? AND party_id=?", (party_type, party_id)).fetchone()
        cur = db.execute("INSERT OR IGNORE INTO ledger(account_id,amount_micros,kind,reference,note) VALUES(?,?,?,?,?)", (account["id"], amount, kind, reference, note))
        if cur.rowcount:
            db.execute("UPDATE accounts SET balance_micros=balance_micros+? WHERE id=?", (amount, account["id"]))


def rate_cdr(db: sqlite3.Connection, payload: dict[str, Any]) -> int:
    uuid = str(payload["uuid"])
    existing = db.execute("SELECT id FROM cdr WHERE uuid=?", (uuid,)).fetchone()
    if existing:
        return int(existing["id"])
    number = "".join(ch for ch in str(payload["called"]) if ch.isdigit())
    match = db.execute("SELECT p.destination_id FROM prefixes p JOIN destinations d ON d.id=p.destination_id AND d.enabled=1 WHERE ? LIKE p.prefix || '%' ORDER BY length(p.prefix) DESC LIMIT 1", (number,)).fetchone()
    destination_id = int(match["destination_id"]) if match else None
    originator_id = int(payload["originator_id"])
    terminator_id = int(payload["terminator_id"])
    seconds = int(payload.get("bill_seconds", 0))
    def amount(kind: str, party: int) -> int:
        if destination_id is None:
            return 0
        row = db.execute("SELECT price_micros,cycle FROM rates WHERE party_type=? AND party_id=? AND destination_id=? AND effective_at<=? ORDER BY effective_at DESC LIMIT 1", (kind, party, destination_id, payload["started_at"])).fetchone()
        return charge_micros(seconds, row["price_micros"], row["cycle"]) if row else 0
    sell, buy = amount("originator", originator_id), amount("terminator", terminator_id)
    with db:
        cur = db.execute("""INSERT INTO cdr(uuid,originator_id,terminator_id,destination_id,caller,called,started_at,answered_at,ended_at,bill_seconds,hangup_cause,sell_micros,buy_micros,raw_json)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (uuid, originator_id, terminator_id, destination_id, payload.get("caller", ""), number, payload["started_at"], payload.get("answered_at"), payload["ended_at"], seconds, payload.get("hangup_cause", ""), sell, buy, json.dumps(payload, separators=(",", ":"))))
        cdr_id = int(cur.lastrowid)
        if sell:
            add_ledger(db, "originator", originator_id, -sell, "call_charge", uuid)
        if buy:
            add_ledger(db, "terminator", terminator_id, -buy, "call_cost", uuid)
    return cdr_id


def seed_demo(db: sqlite3.Connection) -> None:
    with db:
        db.execute("INSERT OR IGNORE INTO originators(id,name) VALUES(1,'Northstar Telecom')")
        db.execute("INSERT OR IGNORE INTO originator_ips(originator_id,cidr) VALUES(1,'198.51.100.10/32')")
        db.execute("INSERT OR IGNORE INTO terminators(id,name,host,tech_prefix) VALUES(1,'Atlas Carrier','203.0.113.44','771')")
        db.execute("INSERT OR IGNORE INTO destinations(id,name) VALUES(1,'Germany Mobile')")
        db.execute("INSERT OR IGNORE INTO prefixes(destination_id,prefix) VALUES(1,'4915')")
        db.execute("INSERT OR IGNORE INTO caller_id_pools(id,name) VALUES(1,'Germany A-numbers')")
        db.execute("INSERT OR IGNORE INTO caller_id_numbers(pool_id,number) VALUES(1,'49301234001')")
        db.execute("INSERT OR IGNORE INTO caller_id_numbers(pool_id,number) VALUES(1,'49301234002')")
        db.execute("INSERT OR IGNORE INTO routes(originator_id,destination_id,terminator_id) VALUES(1,1,1)")
        db.execute("UPDATE routes SET caller_id_pool_id=1 WHERE id=1 AND caller_id_pool_id IS NULL")
        db.execute("INSERT OR IGNORE INTO rates(party_type,party_id,destination_id,price_micros,cycle) VALUES('originator',1,1,42000,'1/1')")
        db.execute("INSERT OR IGNORE INTO rates(party_type,party_id,destination_id,price_micros,cycle) VALUES('terminator',1,1,28000,'6/6')")
    add_ledger(db, "originator", 1, 250_000_000, "topup", "demo-originator")
    add_ledger(db, "terminator", 1, 500_000_000, "topup", "demo-terminator")

