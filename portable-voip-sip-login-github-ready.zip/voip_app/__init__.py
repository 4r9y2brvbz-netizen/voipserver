"""Local-only VoIP management, rating and configuration service."""

__version__ = "0.1.0"

