"""Portable SSH deployer. It never persists private-key material."""

__version__ = "0.1.0"

