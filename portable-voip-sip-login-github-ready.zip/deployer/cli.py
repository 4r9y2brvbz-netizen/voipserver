from __future__ import annotations

import argparse
from pathlib import Path

from .core import Target, deploy, plan, preflight


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Portable VoIP server deployer")
    sub = p.add_subparsers(dest="command", required=True)
    for name in ("plan", "preflight", "deploy"):
        s = sub.add_parser(name)
        s.add_argument("--host", required=True, help="literal IPv4/IPv6 address")
        s.add_argument("--user", required=True)
        s.add_argument("--key", required=True, type=Path)
        s.add_argument("--port", type=int, default=22)
    return p


def main() -> int:
    args = parser().parse_args()
    target = Target(args.host, args.user, args.key.expanduser().resolve(), args.port)
    if args.command == "plan":
        print(plan(target))
        return 0
    result = preflight(target) if args.command == "preflight" else deploy(target, Path(__file__).resolve().parents[1])
    print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, end="")
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())

