from __future__ import annotations

import ipaddress
import shlex
import subprocess
import tarfile
import tempfile
from dataclasses import dataclass
from pathlib import Path


REMOTE_ROOT = "/opt/portable-voip"


@dataclass(frozen=True)
class Target:
    host: str
    user: str
    key: Path
    port: int = 22

    def validate(self) -> None:
        ipaddress.ip_address(self.host)
        if not self.user or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in self.user):
            raise ValueError("SSH user contains unsupported characters")
        if not 1 <= self.port <= 65535:
            raise ValueError("SSH port is outside 1..65535")
        if not self.key.is_file():
            raise ValueError("Private key does not exist")
        mode = self.key.stat().st_mode & 0o777
        if mode & 0o077:
            raise ValueError("Private key permissions are too open; use chmod 600")


def ssh_base(target: Target) -> list[str]:
    target.validate()
    return [
        "ssh", "-o", "BatchMode=yes", "-o", "IdentitiesOnly=yes",
        "-o", "StrictHostKeyChecking=accept-new", "-p", str(target.port),
        "-i", str(target.key), f"{target.user}@{target.host}",
    ]


def run_ssh(target: Target, command: str, timeout: int = 60) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [*ssh_base(target), command], text=True, capture_output=True,
        timeout=timeout, check=False,
    )


PREFLIGHT = r'''set -eu
test "$(id -u)" = 0 || sudo -n true
. /etc/os-release
case "$ID:$VERSION_ID" in ubuntu:22.04|ubuntu:24.04|debian:12) ;; *) echo "UNSUPPORTED_OS=$ID:$VERSION_ID"; exit 21;; esac
command -v systemctl >/dev/null
command -v tar >/dev/null
free_mb=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
disk_mb=$(df -Pm /opt 2>/dev/null | awk 'NR==2 {print $4}' || df -Pm / | awk 'NR==2 {print $4}')
test "$free_mb" -ge 700 || { echo "LOW_MEMORY_MB=$free_mb"; exit 22; }
test "$disk_mb" -ge 4096 || { echo "LOW_DISK_MB=$disk_mb"; exit 23; }
echo "OK os=$ID:$VERSION_ID memory_mb=$free_mb disk_mb=$disk_mb kernel=$(uname -r)"
'''


def _run_ssh_with_input(target: Target, command: str, data: str, timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [*ssh_base(target), command], input=data, text=True, capture_output=True,
        timeout=timeout, check=False,
    )


def preflight(target: Target) -> subprocess.CompletedProcess[str]:
    return _run_ssh_with_input(target, "sh -s", PREFLIGHT, 45)


def make_bundle(project_root: Path, output: Path) -> None:
    allowed = ["voip_app", "deploy", "pyproject.toml", "README.md", "ARCHITECTURE.md"]
    with tarfile.open(output, "w:gz") as archive:
        for name in allowed:
            path = project_root / name
            if path.exists():
                archive.add(path, arcname=name, filter=_safe_tar_filter)


def _safe_tar_filter(info: tarfile.TarInfo) -> tarfile.TarInfo | None:
    parts = Path(info.name).parts
    if "__pycache__" in parts or info.name.endswith((".pyc", ".db", ".key", ".pem")):
        return None
    info.uid = info.gid = 0
    info.uname = info.gname = "root"
    return info


def deploy(target: Target, project_root: Path) -> subprocess.CompletedProcess[str]:
    check = preflight(target)
    if check.returncode:
        return check
    with tempfile.TemporaryDirectory(prefix="portable-voip-") as tmp:
        bundle = Path(tmp) / "bundle.tgz"
        make_bundle(project_root, bundle)
        remote = "/tmp/portable-voip-bundle.tgz"
        scp = subprocess.run([
            "scp", "-o", "BatchMode=yes", "-o", "IdentitiesOnly=yes",
            "-P", str(target.port), "-i", str(target.key), str(bundle),
            f"{target.user}@{target.host}:{remote}",
        ], text=True, capture_output=True, check=False, timeout=180)
        if scp.returncode:
            return scp
        command = f"sudo -n sh -c {shlex.quote(f'mkdir -p {REMOTE_ROOT}/releases/incoming && tar -xzf {remote} -C {REMOTE_ROOT}/releases/incoming && sh {REMOTE_ROOT}/releases/incoming/deploy/install.sh')}"
        return run_ssh(target, command, timeout=900)


def plan(target: Target) -> str:
    target.validate()
    return "\n".join([
        f"Target: {target.user}@{target.host}:{target.port}",
        "1. Read-only OS, sudo, RAM and disk preflight",
        "2. Build a secret-free application bundle locally",
        "3. Copy bundle to /tmp over SSH (private key is not copied)",
        f"4. Run idempotent installer under {REMOTE_ROOT}",
        "5. Preserve a timestamped rollback snapshot before activation",
        "6. Start local panel, nginx, FreeSWITCH and backup timer",
    ])

