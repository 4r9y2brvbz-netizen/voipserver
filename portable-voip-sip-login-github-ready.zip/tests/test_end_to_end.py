from __future__ import annotations

import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.cookiejar import CookieJar
from pathlib import Path

from voip_app.db import connect, ensure_admin, init_db
from voip_app.web import App


class EndToEndTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.db_path = root / "voip.db"
        self.config_dir = root / "generated"
        db = connect(self.db_path)
        try:
            init_db(db)
            ensure_admin(db, "integration-password")
            db.execute("INSERT INTO settings(key,value) VALUES('cdr_token','local-cdr-test-token')")
        finally:
            db.close()
        self.server = App(("127.0.0.1", 0), self.db_path, self.config_dir)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}/api/"
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(CookieJar()))
        self.post("login", {"username": "admin", "password": "integration-password"})

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.tmp.cleanup()

    def request(self, path, method="GET", payload=None, headers=None):
        body = json.dumps(payload).encode() if payload is not None else None
        request = urllib.request.Request(
            self.base + path,
            data=body,
            method=method,
            headers={"Content-Type": "application/json", **(headers or {})},
        )
        with self.opener.open(request, timeout=3) as response:
            return response.status, json.loads(response.read())

    def post(self, path, payload, headers=None):
        return self.request(path, "POST", payload, headers)

    def create_full_route(self):
        _, orig = self.post("originators", {
            "name": "Mobile Client",
            "cidrs": ["198.51.100.10", "198.51.100.32/28"],
        })
        _, term = self.post("terminators", {
            "name": "Belgium Carrier",
            "host": "203.0.113.44",
            "tech_prefix": "6488",
        })
        _, dest = self.post("destinations", {
            "name": "Belgium",
            "prefixes": ["32", "324"],
        })
        _, pool = self.post("caller-id-pools", {
            "name": "Belgium A-numbers",
            "numbers": ["+3225550101", "3225550102", "3225550101"],
        })
        _, route = self.post("routes", {
            "originator_id": orig["id"],
            "terminator_id": term["id"],
            "destination_id": dest["id"],
            "client_tech_prefix": "103",
            "caller_id_pool_id": pool["id"],
            "priority": 10,
        })
        self.post("rates", {
            "party_type": "originator", "party_id": orig["id"],
            "destination_id": dest["id"], "price_micros": 190_000, "cycle": "1/1",
        })
        self.post("rates", {
            "party_type": "terminator", "party_id": term["id"],
            "destination_id": dest["id"], "price_micros": 150_000, "cycle": "6/6",
        })
        self.post("ledger", {
            "party_type": "originator", "party_id": orig["id"],
            "amount_micros": 100_000_000, "kind": "topup", "reference": "orig-opening",
        })
        self.post("ledger", {
            "party_type": "terminator", "party_id": term["id"],
            "amount_micros": 200_000_000, "kind": "topup", "reference": "term-opening",
        })
        return orig["id"], term["id"], dest["id"], route["id"]

    def test_complete_operator_flow_and_cdr_rating(self):
        originator_id, terminator_id, _, route_id = self.create_full_route()

        status, originators = self.request("originators")
        self.assertEqual(status, 200)
        self.assertEqual(originators[0]["name"], "Mobile Client")
        self.assertIn("198.51.100.10/32", originators[0]["ips"])
        self.assertEqual(originators[0]["balance_micros"], 100_000_000)

        _, terminators = self.request("terminators")
        self.assertEqual(terminators[0]["tech_prefix"], "6488")
        self.assertEqual(terminators[0]["balance_micros"], 200_000_000)
        self.assertEqual(terminators[0]["route_count"], 1)

        _, routes = self.request("routes")
        route = routes[0]
        self.assertEqual(route["id"], route_id)
        self.assertEqual(route["destination"], "Belgium")
        self.assertEqual(route["client_tech_prefix"], "103")
        self.assertEqual(route["tech_prefix"], "6488")
        self.assertEqual(route["sell_micros"], 190_000)
        self.assertEqual(route["buy_micros"], 150_000)
        self.assertEqual(route["sell_cycle"], "1/1")
        self.assertEqual(route["buy_cycle"], "6/6")
        self.assertEqual(route["caller_id_pool"], "Belgium A-numbers")
        self.assertEqual(route["caller_id_count"], 2)

        cdr = {
            "uuid": "e2e-call-001",
            "originator_id": originator_id,
            "terminator_id": terminator_id,
            "caller": "491701234567",
            "called": "32470112233",
            "started_at": "2099-01-01 12:00:00",
            "answered_at": "2099-01-01 12:00:01",
            "ended_at": "2099-01-01 12:00:08",
            "bill_seconds": 7,
            "hangup_cause": "NORMAL_CLEARING",
        }
        headers = {"Authorization": "Bearer local-cdr-test-token"}
        status, first = self.post("cdr-ingest", cdr, headers)
        self.assertEqual(status, 201)
        _, duplicate = self.post("cdr-ingest", cdr, headers)
        self.assertEqual(first["id"], duplicate["id"])

        _, rows = self.request("cdr?number=3247011")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["sell_micros"], 22_167)  # 7 sec at 0.1900/min, 1/1
        self.assertEqual(rows[0]["buy_micros"], 30_000)   # 12 billed sec at 0.1500/min, 6/6

        _, accounts = self.request("accounts")
        balances = {(a["party_type"], a["party_id"]): a["balance_micros"] for a in accounts}
        self.assertEqual(balances[("originator", originator_id)], 99_977_833)
        self.assertEqual(balances[("terminator", terminator_id)], 199_970_000)

        status, activated = self.post("config-activate", {})
        self.assertEqual(status, 200)
        self.assertEqual(set(activated["files"]), {"acl.conf.xml", "dialplan.xml", "distributor.conf.xml", "gateways.xml"})
        self.assertIn("portable-originator-", (self.config_dir / "acl.conf.xml").read_text())
        self.assertIn("6488${destination_number}", (self.config_dir / "dialplan.xml").read_text())
        self.assertIn("origination_caller_id_number=${DISTRIBUTOR}", (self.config_dir / "dialplan.xml").read_text())
        distributor = (self.config_dir / "distributor.conf.xml").read_text()
        self.assertIn('name="3225550101" weight="1"', distributor)
        self.assertIn('name="3225550102" weight="1"', distributor)

    def test_rejects_invalid_cidr_and_unauthorized_cdr(self):
        with self.assertRaises(urllib.error.HTTPError) as invalid:
            self.post("originators", {"name": "Invalid", "cidrs": ["999.2.3.4"]})
        self.assertEqual(invalid.exception.code, 400)
        invalid.exception.close()
        with self.assertRaises(urllib.error.HTTPError) as unauthorized:
            self.post("cdr-ingest", {"uuid": "x"})
        self.assertEqual(unauthorized.exception.code, 401)
        unauthorized.exception.close()
        with self.assertRaises(urllib.error.HTTPError) as invalid_caller:
            self.post("caller-id-pools", {"name": "Bad", "numbers": ["123"]})
        self.assertEqual(invalid_caller.exception.code, 400)
        invalid_caller.exception.close()

    def test_duplicate_balance_reference_is_idempotent(self):
        originator_id, _, _, _ = self.create_full_route()
        operation = {
            "party_type": "originator", "party_id": originator_id,
            "amount_micros": 5_000_000, "kind": "topup", "reference": "bank-transfer-42",
        }
        self.post("ledger", operation)
        self.post("ledger", operation)
        _, accounts = self.request("accounts")
        account = next(a for a in accounts if a["party_type"] == "originator")
        self.assertEqual(account["balance_micros"], 105_000_000)

    def test_sip_registration_terminator_keeps_password_private(self):
        status, created = self.post("terminators", {
            "name": "SIPNET",
            "connection_type": "registration",
            "host": "sipnet.ru",
            "sip_username": "0042732XXX",
            "sip_password": "secret<&password",
            "sip_realm": "",
            "sip_transport": "udp",
            "tech_prefix": "",
        })
        self.assertEqual(status, 201)
        _, rows = self.request("terminators")
        row = next(item for item in rows if item["id"] == created["id"])
        self.assertEqual(row["connection_type"], "registration")
        self.assertEqual(row["sip_username"], "0042732XXX")
        self.assertNotIn("sip_password", row)

        _, preview = self.request("config-preview")
        self.assertIn('name="password" value="********"', preview["gateways.xml"])
        self.assertNotIn("secret", preview["gateways.xml"])

        _, activated = self.post("config-activate", {})
        self.assertEqual(activated["ok"], True)
        gateway = (self.config_dir / "gateways.xml").read_text()
        self.assertIn('name="register" value="true"', gateway)
        self.assertIn('name="password" value="secret&lt;&amp;password"', gateway)

    def test_sip_registration_requires_credentials(self):
        with self.assertRaises(urllib.error.HTTPError) as missing:
            self.post("terminators", {
                "name": "Incomplete",
                "connection_type": "registration",
                "host": "sip.example.com",
                "sip_username": "user",
                "sip_password": "",
            })
        self.assertEqual(missing.exception.code, 400)
        missing.exception.close()

