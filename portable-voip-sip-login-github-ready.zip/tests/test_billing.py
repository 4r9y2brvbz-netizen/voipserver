import tempfile
import unittest
from pathlib import Path

from voip_app.db import add_ledger, billed_seconds, charge_micros, connect, init_db, rate_cdr, seed_demo


class BillingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.path = Path(self.tmp.name) / "test.db"
        self.db = connect(self.path); init_db(self.db); seed_demo(self.db)
    def tearDown(self): self.db.close(); self.tmp.cleanup()
    def test_cycles(self):
        self.assertEqual(billed_seconds(1, "1/1"), 1)
        self.assertEqual(billed_seconds(7, "6/6"), 12)
        self.assertEqual(billed_seconds(1, "60/1"), 60)
        self.assertEqual(charge_micros(30, 60_000, "1/1"), 30_000)
    def test_cdr_is_idempotent_and_balances_both_sides(self):
        payload={"uuid":"call-1","originator_id":1,"terminator_id":1,"caller":"12025550000","called":"49151234567","started_at":"2099-01-01 00:00:00","answered_at":"2099-01-01 00:00:01","ended_at":"2099-01-01 00:00:31","bill_seconds":30,"hangup_cause":"NORMAL_CLEARING"}
        first=rate_cdr(self.db,payload); second=rate_cdr(self.db,payload)
        self.assertEqual(first,second)
        self.assertEqual(self.db.execute("select count(*) from cdr").fetchone()[0],1)
        balances={r[0]:r[1] for r in self.db.execute("select party_type,balance_micros from accounts")}
        self.assertEqual(balances["originator"],249_979_000)
        self.assertEqual(balances["terminator"],499_986_000)

