import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
from voip_app.db import connect, init_db, seed_demo, validate_cidr
from voip_app.freeswitch import generate, write_atomic

class ConfigTests(unittest.TestCase):
    def test_validation_and_generation(self):
        with tempfile.TemporaryDirectory() as d:
            db=connect(Path(d)/"db"); init_db(db); seed_demo(db); files=generate(db)
            self.assertEqual(validate_cidr("198.51.100.10"),"198.51.100.10/32")
            self.assertIn('cidr="198.51.100.10/32"',files["acl.conf.xml"])
            self.assertIn('portable-originator-1',files["acl.conf.xml"])
            self.assertIn('term_1',files["gateways.xml"])
            for content in files.values():
                ET.fromstring(content)
            target=Path(d)/"generated"; write_atomic(files,target)
            self.assertEqual(set(p.name for p in target.iterdir()),set(files))
            self.assertIn("distributor.conf.xml", files)
            db.close()

    def test_registered_gateway_uses_credentials_and_redacts_preview(self):
        with tempfile.TemporaryDirectory() as d:
            db = connect(Path(d) / "db")
            init_db(db)
            db.execute("""INSERT INTO terminators
              (name,host,connection_type,sip_username,sip_password,sip_realm,sip_transport)
              VALUES(?,?,?,?,?,?,?)""", (
                "SIPNET", "sipnet.ru", "registration", "0042732XXX",
                "p&ss<word>", "sipnet.ru", "udp",
            ))
            generated = generate(db)
            gateway = generated["gateways.xml"]
            ET.fromstring(gateway)
            self.assertIn('name="register" value="true"', gateway)
            self.assertIn('name="username" value="0042732XXX"', gateway)
            self.assertIn('name="password" value="p&amp;ss&lt;word&gt;"', gateway)
            self.assertIn('name="from-domain" value="sipnet.ru"', gateway)
            self.assertIn('name="ping" value="30"', gateway)
            preview = generate(db, redact_secrets=True)["gateways.xml"]
            self.assertIn('name="password" value="********"', preview)
            self.assertNotIn("p&amp;ss", preview)
            db.close()

    def test_existing_database_gets_registration_columns(self):
        with tempfile.TemporaryDirectory() as d:
            db = connect(Path(d) / "db")
            db.execute("CREATE TABLE terminators (id INTEGER PRIMARY KEY,name TEXT NOT NULL,host TEXT NOT NULL,tech_prefix TEXT NOT NULL DEFAULT '',enabled INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
            init_db(db)
            columns = {row["name"] for row in db.execute("PRAGMA table_info(terminators)")}
            self.assertTrue({"connection_type", "sip_username", "sip_password", "sip_realm", "sip_transport"} <= columns)
            db.close()

