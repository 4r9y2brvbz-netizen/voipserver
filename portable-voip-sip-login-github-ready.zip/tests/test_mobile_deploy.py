import unittest
from pathlib import Path


ROOT = Path(__file__).parents[1]


class MobileDeployTests(unittest.TestCase):
    def test_cloud_init_remains_a_template(self):
        text = (ROOT / "cloud-init.example.yaml").read_text()
        self.assertTrue(text.startswith("#cloud-config"))
        self.assertIn("https://github.com/CHANGE-ME/", text)
        self.assertNotIn("SIGNALWIRE_TOKEN", text)

    def test_bootstrap_has_no_embedded_credentials(self):
        text = (ROOT / "bootstrap.sh").read_text()
        self.assertNotIn("SIGNALWIRE_TOKEN", text)
        self.assertNotIn("PRIVATE KEY", text)
        self.assertIn("/var/lib/portable-voip-install.status", text)

    def test_source_installer_is_pinned_and_single_threaded(self):
        text = (ROOT / "deploy" / "install-freeswitch-source.sh").read_text()
        self.assertIn("FS_VERSION=v1.10.12", text)
        self.assertIn("SOFIA_VERSION=v1.13.17", text)
        self.assertIn("SPANDSP_VERSION=v3.1.1", text)
        self.assertIn("JOBS=${FREESWITCH_BUILD_JOBS:-1}", text)
        self.assertNotIn("SIGNALWIRE_TOKEN", text)

    def test_firewall_allows_external_sip_and_rtp(self):
        text = (ROOT / "deploy" / "nftables.conf").read_text()
        self.assertIn("5080", text)
        self.assertIn("5081", text)
        self.assertIn("16384-32768", text)

    def test_coexist_mode_uses_separate_panel_port(self):
        wrapper = (ROOT / "deploy" / "install-coexist.sh").read_text()
        unit = (ROOT / "deploy" / "portable-voip-coexist.service").read_text()
        installer = (ROOT / "deploy" / "install.sh").read_text()
        self.assertIn("PORTABLE_VOIP_COEXIST=1", wrapper)
        self.assertIn("--host 0.0.0.0 --port 18088", unit)
        self.assertIn('if [ "$COEXIST" = 1 ]', installer)
        self.assertIn("mode=coexist panel_port=18088", installer)

